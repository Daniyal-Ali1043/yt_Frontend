import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import DownloadPage from './pages/DownloadPage';
import DownloadByUrl from "./pages/DownloadByUrl";
import VideoPlayPage from './pages/VideoPlayPage';
function app() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/download-search" element={<DownloadPage />} />
        <Route path="/download-link" element={<DownloadByUrl />} />
        <Route path="/playsearch-videos" element={<VideoPlayPage/>} />
      </Routes>
    </Router>
  );
}

export default app;
