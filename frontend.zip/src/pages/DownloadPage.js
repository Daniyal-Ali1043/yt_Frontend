import React, { useState } from "react";
import axios from "axios";
import Navbar from "../components/Navbar";

const DownloadPage = () => {
  const [query, setQuery] = useState("");
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");

  const backendUrl = "http://localhost:5000"; // Adjust if needed

  // 🔍 Search Videos from Backend
  const handleSearch = async () => {
    if (!query) return alert("Please enter a search term!");
    try {
      setLoading(true);
      const response = await axios.get(`${backendUrl}/search`, {
        params: { query },
      });
      setVideos(response.data);
      setError("");
    } catch (err) {
      console.error("Search Error:", err);
      setError("Failed to fetch videos. Try again!");
    } finally {
      setLoading(false);
    }
  };

  // 📥 Download Video with Progress Bar
  const handleDownload = async (videoId) => {
    setLoading(true);
    setProgress(0);
    console.log("Download started...");

    try {
      const response = await axios({
        method: "GET",
        url: `${backendUrl}/download`,
        params: { videoId },
        responseType: "blob",
        onDownloadProgress: (progressEvent) => {
          console.log("Progress Event:", progressEvent);
          if (progressEvent.lengthComputable) {
            const percentCompleted = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            setProgress(percentCompleted);
            console.log(`Progress: ${percentCompleted}%`);
          }
        },
      });

      // Create a download link and trigger it
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `${videoId}.mp4`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error("Download Error:", error);
      setError("Failed to download video.");
    } finally {
      setTimeout(() => {
        setProgress(0);
        setLoading(false);
      }, 1000); // Reset progress after completion
    }
  };

  return (
    <>
      <div className="bg-gray-900 text-white min-h-screen">
        <Navbar />

        {/* 📊 Download Progress Bar */}
        {loading && (
          <div className="fixed top-[4rem] left-0 w-full z-50">
            <div
              className="h-1 bg-red-500 transition-all ease-in-out duration-300"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        )}

        <div className="pt-24 flex flex-col items-center p-8">
          <h1 className="text-4xl font-bold mb-8">YouTube Video Downloader</h1>

          {/* 🔍 Search Input */}
          <div className="flex items-center mb-8 w-full max-w-xl">
            <input
              type="text"
              placeholder="Search YouTube videos..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-grow p-3 rounded-l-lg bg-gray-800 text-white outline-none"
            />
            <button
              onClick={handleSearch}
              className="px-6 py-3 bg-red-500 hover:bg-red-600 rounded-r-lg transition"
            >
              Search
            </button>
          </div>

          {/* 🔄 Loading State */}
          {loading && (
            <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-30 backdrop-blur-md z-50">
              <div className="relative">
                <div className="w-32 h-32 border-8 border-transparent border-t-blue-500 border-b-blue-500 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-white text-xl font-semibold animate-pulse">Loading...</span>
                </div>
              </div>
            </div>
          )}

          {/* ❌ Error Message */}
          {error && <p className="text-red-400">{error}</p>}

          {/* 📋 Display Video Results */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 w-full max-w-6xl">
            {videos.map((video) => (
              <div
                key={video.videoId}
                className="bg-gray-800 p-4 rounded-lg shadow-lg flex flex-col items-center"
              >
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="rounded-lg mb-4 w-full"
                />
                <h2 className="text-lg font-semibold mb-2">{video.title}</h2>
                <p className="text-sm text-gray-400">{video.channelTitle}</p>

                <button
                  onClick={() => handleDownload(video.videoId)}
                  className="mt-4 bg-green-500 hover:bg-green-600 px-4 py-2 rounded transition"
                >
                  ⬇ Download
                </button>
              </div>
            ))}
          </div>

          {/* ℹ️ No Videos Found */}
          {!loading && !error && videos.length === 0 && (
            <p className="mt-8">Download your favorite YouTube videos instantly!</p>
          )}
        </div>
      </div>
    </>
  );
};

export default DownloadPage;
